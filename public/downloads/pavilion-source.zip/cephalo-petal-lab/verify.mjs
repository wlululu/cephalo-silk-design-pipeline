import assert from 'node:assert/strict';
import {makeModel,properties} from './dist/model.js';
import {solve} from './dist/solver.js';
const m=makeModel();
// Analytic independent benchmark: 4 m cantilever with a 1 kN transverse tip load.
const beam={...m,nodes:[{id:0,position:[0,0,0]},{id:1,position:[4,0,0]}],members:[{id:0,nodes:[0,1],section:'arch',material:'steel',type:'frame'}],faces:[],supports:[{node:0}]};
const b=solve(beam,{pressure:0,nodalLoads:[{node:1,force:[0,-1000,0]}]}),p=properties(beam,beam.members[0]);
const expected=1000*4**3/(3*p.E*p.I);assert.ok(Math.abs(-b.displacements[1][1]/expected-1)<1e-9,'Cantilever bending benchmark');
assert.ok(Math.abs(b.reactions[0].moment[2]-4000)<1e-6,'Fixed-end moment');
const zero=solve(m,{pressure:0});assert.equal(zero.maxDisplacement,0);
const base=solve(m),double=solve(m,{pressure:600});assert.ok(Math.abs(double.maxDisplacement/base.maxDisplacement-2)<1e-6,'Linear load scaling');
const checks=[];for(let loadCase of ['Gravity','Uplift','Lateral','Asymmetric'])for(const params of [{pressure:300,thickness:1,stiffness:1},{pressure:1500,thickness:.6,stiffness:.25},{pressure:1500,thickness:1.8,stiffness:3}]){
 const r=solve(m,{...params,loadCase});assert.ok(r.converged,loadCase+' convergence');assert.ok(Math.hypot(...r.balance)/Math.max(1,Math.hypot(...r.totalLoad))<1e-5,loadCase+' force balance');assert.ok(r.magnitudes.every(Number.isFinite));checks.push({loadCase,...params,max_mm:r.maxDisplacement*1000,slack:r.slack,residual:r.relativeResidual});
}
console.log(JSON.stringify({cantilever:{computed_m:-b.displacements[1][1],expected_m:expected},zero_load:'passed',load_scaling:'passed',cases:checks},null,2));
