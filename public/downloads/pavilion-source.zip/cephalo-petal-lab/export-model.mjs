import {makeModel} from './dist/model.js';
import {solve} from './dist/solver.js';
import fs from 'node:fs';
const m=makeModel(),r=solve(m);fs.writeFileSync('dist/model.json',JSON.stringify(m,null,2));fs.writeFileSync('dist/baseline-results.json',JSON.stringify(r,null,2));console.log({nodes:m.nodes.length,members:m.members.length,...Object.fromEntries(Object.entries(r).filter(([k])=>['maxDisplacement','slack','iterations','relativeResidual','converged','balance','totalLoad'].includes(k)))});
