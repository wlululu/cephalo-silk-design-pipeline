"""Create the user-facing source bundle, excluding build output and local state."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import os
root=Path(__file__).resolve().parents[1]
out=root/'public/bridge/cephalo-bridge-v2-final.zip'
skip={'node_modules','.git','.sites-runtime','.wrangler','.next','.vinext','dist','portable-dist','outputs','work','.agents','.codex','__pycache__'}
with ZipFile(out,'w',ZIP_DEFLATED) as z:
    for parent,dirs,files in os.walk(root):
        dirs[:]=[d for d in dirs if d not in skip]
        for name in sorted(files):
            p=Path(parent)/name
            if name.startswith('.env') or name.endswith(('.zip','.log','.tsbuildinfo')): continue
            z.write(p,Path('cephalo-bridge')/p.relative_to(root))
    # Include the tested static build, avoiding recursive copies of the source ZIP.
    built=root/'portable-dist'
    assert (built/'index.html').is_file(), 'Run npm run build:portable first'
    for p in built.rglob('*'):
        if p.is_file() and p.suffix!='.zip':
            z.write(p,Path('cephalo-bridge/standalone')/p.relative_to(built))
with ZipFile(out) as z:
    assert z.testzip() is None
    assert 'cephalo-bridge/public/bridge/model.json' in z.namelist()
    assert 'cephalo-bridge/standalone/index.html' in z.namelist()
print(out, out.stat().st_size)
