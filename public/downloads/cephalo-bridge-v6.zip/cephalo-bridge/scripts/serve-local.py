"""Serve the prebuilt portable app locally; no npm or hosting account required."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import sys
import threading
import webbrowser

root=Path(__file__).resolve().parents[1]
folder=root/'standalone'
if not (folder/'index.html').is_file():
    folder=root/'portable-dist'
if not (folder/'index.html').is_file():
    raise SystemExit('Prebuilt app missing. Run npm ci, then npm run build:portable first.')
port=int(sys.argv[1]) if len(sys.argv)>1 else 8000
url=f'http://localhost:{port}/'
handler=partial(SimpleHTTPRequestHandler,directory=str(folder))
try:
    server=ThreadingHTTPServer(('127.0.0.1',port),handler)
except OSError as error:
    raise SystemExit(f'{error}\nTry another port: python scripts/serve-local.py 8001')
print(f'Cephalo bridge: {url}\nKeep this terminal open. Press Ctrl+C to stop.',flush=True)
threading.Timer(.5,lambda:webbrowser.open(url)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
