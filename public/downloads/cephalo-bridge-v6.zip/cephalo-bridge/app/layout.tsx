import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'Cephalo · Hybrid Arch & Web Bridge',description:'An interactive 3D structural interpretation of a spider-web-inspired bridge. Explore lattice-filled arches and a tension-only web, loads and elastic response.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>;}
